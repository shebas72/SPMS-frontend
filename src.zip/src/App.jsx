import { Navigate, Route, Routes } from 'react-router-dom'
import LoginPage from '@/features/auth/LoginPage'
import ProtectedRoute from '@/components/ProtectedRoute'
import AppLayout from '@/components/layout/AppLayout'
import PlaceholderPage from '@/pages/PlaceholderPage'
import NotFoundPage from '@/pages/NotFoundPage'

const PAGES = [
  ['strategy-house', 'nav.strategyHouse'],
  ['strategy-map', 'nav.strategyMap'],
  ['objectives', 'nav.objectives'],
  ['departments', 'nav.departments'],
  ['kpis', 'nav.kpis'],
  ['projects', 'nav.projects'],
  ['analysis', 'nav.analysis'],
]

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedRoute />}>
        <Route element={<AppLayout />}>
          <Route index element={<PlaceholderPage titleKey="nav.dashboard" />} />
          {PAGES.map(([path, key]) => (
            <Route key={path} path={path} element={<PlaceholderPage titleKey={key} />} />
          ))}
          <Route path="*" element={<NotFoundPage />} />
        </Route>
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}
