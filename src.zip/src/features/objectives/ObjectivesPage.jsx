import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { useTranslation } from 'react-i18next'
import api from '@/lib/api'
import { fetchAll } from '@/lib/fetchAll'
import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import { useDashboard } from '@/features/dashboard/useDashboard'
import { PeriodPicker } from '@/features/dashboard/DashboardPage'
import ObjectivesTrend from './ObjectivesTrend'
import { ViewSwitch } from '@/features/performance/trendCharts'
import { Counts, ScoreBar, StatusBadge, keyOf, statusOf, useFormat } from '@/features/dashboard/ui'

// GET /dashboard/objectives supports ?perspective_id=, so filtering happens on the server.
// With series=1 the response also carries each objective's monthly series and the company overall (trend view).
function useObjectives({ year, month }, perspectiveId, withSeries) {
  return useQuery({
    queryKey: ['objectives-page', year ?? null, month ?? null, perspectiveId, withSeries],
    queryFn: async () => {
      const params = { year, month, perspective_id: perspectiveId || undefined, series: withSeries ? 1 : undefined }
      return (await api.get('/dashboard/objectives', { params })).data
    },
    placeholderData: (prev) => prev,
  })
}

function Block({ label, block }) {
  const { n } = useFormat()
  return (
    <div>
      <dt className="text-xs text-muted">{label}</dt>
      <dd className="mt-1">
        <div className="flex items-baseline justify-between gap-2">
          <span className="text-2xl font-semibold tabular-nums" style={{ color: statusOf(keyOf(block.score, block.status)).text }}>{n(block.score)}</span>
          <StatusBadge status={block.status} score={block.score} />
        </div>
        <ScoreBar className="mt-2" score={block.score} status={block.status} />
      </dd>
    </div>
  )
}

function ObjectiveCard({ o, monthLabel, links }) {
  const { t } = useTranslation()
  const { n, pick } = useFormat()
  const cur = o.current ?? {}
  const ytd = o.ytd ?? {}
  const p = o.perspective
  return (
    <article className="rounded-lg border border-line bg-white p-5" style={{ borderTop: `3px solid ${p?.color ?? '#8A8F98'}` }}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="text-xs text-muted">{o.code}</p>
          <h2 className="mt-1 text-sm font-semibold">{pick(o)}</h2>
        </div>
        <span className="shrink-0 text-xs text-muted">{t('dashboard.weight', { value: n(Number(o.weight)) })}</span>
      </div>
      {p && (
        <p className="mt-2 inline-flex items-center gap-1.5 text-xs text-muted">
          <span className="h-2 w-2 rounded-full" style={{ background: p.color }} aria-hidden="true" />
          {pick(p)}
        </p>
      )}
      <dl className="mt-4 grid grid-cols-2 gap-4">
        <Block label={monthLabel} block={cur} />
        <Block label={t('dashboard.ytd')} block={ytd} />
      </dl>
      <p className="mt-4 text-xs text-muted">
        {links.projects + links.initiatives === 0 ? t('objectives.linkedNone') : t('objectives.linked', { projects: n(links.projects), initiatives: n(links.initiatives), avg: n(links.avg == null ? null : Math.round(links.avg * 10) / 10) })}
      </p>
      <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-line pt-3">
        <Counts data={cur} />
        <span className="text-xs text-muted">{t('strategyMap.kpiCount', { count: cur.kpi_count ?? 0 })}</span>
      </div>
    </article>
  )
}

export default function ObjectivesPage() {
  const { t } = useTranslation()
  const { pick, monthLong } = useFormat()
  const [period, setPeriod] = useState({})
  const [perspectiveId, setPerspectiveId] = useState('')
  const [sort, setSort] = useState('order')
  const [view, setView] = useState('trend')
  const dash = useDashboard(period)
  const objectives = useObjectives(period, perspectiveId, view === 'trend')
  const year = dash.data?.period.year
  const projects = useQuery({ queryKey: ['obj-projects', year], queryFn: () => fetchAll('/projects', { year }), enabled: Boolean(year) })
  const initiatives = useQuery({ queryKey: ['obj-initiatives', year], queryFn: () => fetchAll('/initiatives', { year }), enabled: Boolean(year) })
  const linksOf = (id) => {
    const ps = (projects.data ?? []).filter((x) => x.objectives?.some((ob) => ob.id === id))
    return { projects: ps.length, initiatives: (initiatives.data ?? []).filter((x) => x.strategic_objective_id === id).length, avg: ps.length ? ps.reduce((sum, x) => sum + x.completion_pct, 0) / ps.length : null }
  }

  if (dash.isLoading || objectives.isLoading) return <p className="text-muted">{t('common.loading')}</p>
  if (dash.isError || objectives.isError || !dash.data) {
    return (
      <div className="max-w-md rounded-lg border border-line bg-white p-5">
        <p className="text-sm">{t('objectives.error')}</p>
        <Button className="mt-4" variant="outline" size="sm" onClick={() => { dash.refetch(); objectives.refetch() }}>{t('dashboard.retry')}</Button>
      </div>
    )
  }

  const rows = [...(objectives.data?.data ?? [])]
  if (sort === 'worst') rows.sort((a, b) => (a.current?.score ?? Infinity) - (b.current?.score ?? Infinity))
  const monthLabel = monthLong(dash.data.period.month)
  const chips = [{ id: '', label: t('objectives.all') }, ...dash.data.perspectives.map((p) => ({ id: String(p.id), label: pick(p), color: p.color }))]

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-semibold">{t('nav.objectives')}</h1>
        <div className="flex flex-wrap items-center gap-3">
          <ViewSwitch
            label={t('objectives.view')}
            value={view}
            onChange={setView}
            options={[{ value: 'trend', label: t('objectives.viewTrend') }, { value: 'cards', label: t('objectives.viewCards') }]}
          />
          <PeriodPicker period={dash.data.period} onChange={setPeriod} />
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex flex-wrap gap-2" role="group" aria-label={t('objectives.filter')}>
          {chips.map((c) => (
            <button
              key={c.id}
              type="button"
              aria-pressed={perspectiveId === c.id}
              onClick={() => setPerspectiveId(c.id)}
              className={cn(
                'inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-sm',
                perspectiveId === c.id ? 'border-ink bg-ink text-white' : 'border-line bg-white text-ink hover:bg-brand-soft',
              )}
            >
              {c.color && <span className="h-2 w-2 rounded-full" style={{ background: c.color }} aria-hidden="true" />}
              {c.label}
            </button>
          ))}
        </div>
        <label className="inline-flex items-center gap-2 text-sm text-muted">
          {t('objectives.sort')}
          <select value={sort} onChange={(e) => setSort(e.target.value)} className="h-9 rounded-md border border-line bg-white px-2 text-sm text-ink">
            <option value="order">{t('objectives.sortOrder')}</option>
            <option value="worst">{t('objectives.sortWorst')}</option>
          </select>
        </label>
      </div>

      {rows.length === 0 ? (
        <p className="rounded-lg border border-dashed border-line p-6 text-sm text-muted">{t('objectives.empty')}</p>
      ) : view === 'trend' ? (
        <ObjectivesTrend rows={rows} overall={objectives.data?.overall} period={dash.data.period} />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 2xl:grid-cols-3">
          {rows.map((o) => <ObjectiveCard key={o.id} o={o} monthLabel={monthLabel} links={linksOf(o.id)} />)}
        </div>
      )}
    </div>
  )
}
